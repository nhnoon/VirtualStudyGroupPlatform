# SRS Draft Outline
- Functional reqs
- Non-functional reqs
- Use cases
