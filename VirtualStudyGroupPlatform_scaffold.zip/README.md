
# VirtualStudyGroupPlatform
Starter scaffold for the Virtual Study Group Platform.
See backend/requirements.txt, database/schema.sql, and frontend/index.html.
